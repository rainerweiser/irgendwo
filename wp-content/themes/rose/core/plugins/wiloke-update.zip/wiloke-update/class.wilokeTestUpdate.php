<?php
/*
Plugin Name: Wiloke Update
Plugin URI: http://wiloke.com
Author URI: wiloke
Author URI: http://wiloke.com
Version: 0.1
*/


if ( !class_exists('wilokeUpdate') )
{
	class wilokeUpdate
	{
		public $envatoAPIURL = 'https://api.envato.com/v2/market/buyer/list-purchases';
		public $wilokeAPIURL = 'http://wiloke.com/wp-json/wp/v2/wiloke_themeforeost_api/';
		public $envatoAPIKey = '';
		public $aInAuthor 	 =  array('next-theme', 'wiloke');
		public $themeInfoKey = '_wiloke_theme_info';
		private $aThemes = array();
		public  $aPlugins = array();
		public $aThemeInfo = array();
		public $cacheIterval = 60*60*24;
		public $themeKey = '';
		private static $wp_plugins = array();
		static $plugins;

		// ?filter_by=wordpress-themes
		public function __construct()
		{	
			// add_filter('http_request_args', array( $this, 'update_check' ), 5, 2 );
			add_action('init', array($this, 'theme_name'));
			add_action('init', array($this, 'init'));
			// add_action('init', array($this, 'test'));
			
			// add_action('admin_menu', array($this, 'wiloke_menu_area'));

			// Inject plugin updates into the response array.
			add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'update_plugins' ) );
			add_filter( 'pre_set_transient_update_plugins', array( $this, 'update_plugins' ) );
		}

		public function test()
		{
			$this->update_plugins();
		}

		public function get_option_name($key='')
		{
			return 'wiloke_tfp_'.$key;
		}

		public function theme_name()
		{
			$oTheme = wp_get_theme();
			
			$this->themeKey = $this->handle_text($oTheme->Name);

			$this->aThemeInfo = array('name'=>$oTheme->Name,'author'=>$oTheme->Author);
		}

		public function update_plugins($transient)
		{
			// send purchased code
			$this->set_plugins();
			self::$wp_plugins = self::wp_plugins();

			if ( empty($this->aPlugins) || empty(self::$plugins) )
				return;

			foreach ( $this->aPlugins as $plugin => $aInfo ) {
				
				if ( isset( self::$wp_plugins[$plugin] ) && version_compare( self::$wp_plugins[$plugin]['Version'], $aInfo['version'], '<' ) ) {
					
					$_plugin = array(
						'slug'        => $aInfo['slug'],
						'plugin'      => $plugin,
						'new_version' => $aInfo['version'],
						'url'         => $aInfo['url'],
						'package'     => $aInfo['package']
					);
					
					if ( empty($transient) )
					{
						$transient = new StdClass;
					}

					$transient->response[$plugin] = (object)$_plugin;
					
				}
			}
			
			return $transient;
		}

		/**
		 * Get the list of WordPress plugins
		 *
		 * @since 1.0.0
		 *
		 * @param bool $flush Forces a cache flush. Default is 'false'.
		 * @return array
		 */
		public static function wp_plugins( $flush = false ) {
			if ( empty( self::$wp_plugins ) || true === $flush ) {
				wp_cache_flush();
				if ( ! function_exists( 'get_plugins' ) ) {
					require_once ABSPATH . 'wp-admin/includes/plugin.php';
				}
				self::$wp_plugins = get_plugins();
			}

			return self::$wp_plugins;
		}

		public function set_plugins()
		{
			$this->aPlugins = get_transient($this->get_option_name($this->themeKey).'_plugins');
			
			
			if ( !isset($this->aThemes[$this->aThemeInfo['name']]['code']) || empty($this->aThemes[$this->aThemeInfo['name']]['code']) )
				return;

			if ( false === $this->aPlugins )
			{
				$request_args = array(
					'headers' => array(
						// 'Authorization' => 'Bearer 86301b58-2b56-42ca-bfea-f866a1104f4d'
						'Authorization' => 'Bearer ' . $this->aThemes[$this->aThemeInfo['name']]['code']
					),
					'sslverify' => false, // for localhost,
					'timeout'   => 60
				);

				$this->aPlugins = $this->request($this->wilokeAPIURL.$this->themeKey.'/'.base64_encode($this->aThemes[$this->aThemeInfo['name']]['code']), $request_args);

				if ( !empty($this->aPlugins) )
				{
					foreach ( $this->aPlugins as $aInfo )
					{
						$this->aPlugins[$aInfo['fileinit']]['slug']    =  dirname($aInfo['fileinit']);
						$this->aPlugins[$aInfo['fileinit']]['plugin']  =  $aInfo['fileinit'];
						$this->aPlugins[$aInfo['fileinit']]['version'] =  $aInfo['version'];
						$this->aPlugins[$aInfo['fileinit']]['url'] 	 =  'http://wiloke.com';
						$this->aPlugins[$aInfo['fileinit']]['package'] =  $aInfo['file'];
					}

					delete_transient($this->get_option_name($this->themeKey).'_plugins');
					set_transient($this->get_option_name($this->themeKey).'_plugins', $this->aPlugins, $this->cacheIterval);
				}
			}
		}

		public function handle_text($text)
		{
			$text = strtolower($text);
			$text = stripslashes($text);
			$text = str_replace( array(' ', '-'), array('_', '_'), $text);
			return $text;
		}

		/**
		 * Disables requests to the wp.org repository for premium themes.
		 *
		 * @since 1.0.0
		 *
		 * @param array  $request An array of HTTP request arguments.
		 * @param string $url The request URL.
		 * @return array
		 */
		public function update_check( $request, $url ) 
		{
			
			// Theme update request.
			if ( false !== strpos( $url, '//api.wordpress.org/themes/update-check/1.1/' ) ) {

				/**
				 * Excluded theme slugs that should never ping the WordPress API.
				 * We don't need the extra http requests for themes we know are premium.
				 */
				self::set_themes();
				$installed = self::$themes['installed'];

				// Decode JSON so we can manipulate the array.
				$data = json_decode( $request['body']['themes'] );

				// Remove the excluded themes.
				foreach ( $installed as $slug => $id ) {
					unset( $data->themes->$slug );
				}

				// Encode back into JSON and update the response.
				$request['body']['themes'] = wp_json_encode( $data );
			}

			// Plugin update request.
			if ( false !== strpos( $url, '//api.wordpress.org/plugins/update-check/1.1/' ) ) {

				/**
				 * Excluded theme slugs that should never ping the WordPress API.
				 * We don't need the extra http requests for themes we know are premium.
				 */
				self::set_plugins();
				$installed = self::$plugins['installed'];

				// Decode JSON so we can manipulate the array.
				$data = json_decode( $request['body']['plugins'] );

				// Remove the excluded themes.
				foreach ( $installed as $slug => $id ) {
					unset( $data->plugins->$slug );
				}

				// Encode back into JSON and update the response.
				$request['body']['plugins'] = wp_json_encode( $data );
			}

			return $request;
		}

		public function init()
		{
			if ( !class_exists('Envato_Market') )
				return;
			$this->envatoAPIKey = envato_market()->get_option( 'token' );

			$aCache = get_transient($this->themeInfoKey);

			if ( $aCache === false )
			{
				$response = $this->request($this->envatoAPIURL.'?filter_by=wordpress-themes');

				if ( is_wp_error($response) || empty($response) )
				{
					return;
				}

				self::wiloke_get_wiloke_themes($response);
			}else{
				$this->aThemeInfo = $aCache;
			}
			
		}

		public function wiloke_menu_area()
		{
			add_menu_page('Wiloke Update', 'Wiloke Update', 'edit_theme_options', 'wiloke-update', array($this, 'wiloke_update_working'));
		}

		public function wiloke_update_working()
		{

		}

		private function wiloke_get_wiloke_themes($response)
		{
			if ( empty($response) )
				return;

			$aItems = array();

			foreach ( $response['results'] as $aItem )
			{
				 if ( $aItem['item']['author_username'] == 'wiloke' )
				 {
					unset($aItem['item']['description']);
					unset($aItem['item']['attributes']);
					$key = explode(' ', $aItem['item']['name']);
					$aItems[$key[0]] = $aItem;
				 }
			}

			$this->aThemes = $aItems;
			set_transient($this->themeInfoKey, $aItems, $this->cacheIterval);
		}

		private function request( $url, $args = array() )
		{
			$defaults = array(
				'headers' => array(
					'Authorization' => 'Bearer '.$this->envatoAPIKey,
				),
				'timeout' => 20,
			);
			$args = wp_parse_args( $args, $defaults );

			$token = trim( str_replace( 'Bearer', '', $args['headers']['Authorization'] ) );
			if ( empty( $token ) ) {
				return new WP_Error( 'api_token_error', __( 'An API token is required.', 'envato-market' ) );
			}

			// Make an API request.
			$response = wp_remote_get( esc_url_raw( $url ), $args );

			// Check the response code.
			$response_code    = wp_remote_retrieve_response_code( $response );
			$response_message = wp_remote_retrieve_response_message( $response );

			if ( 200 !== $response_code && ! empty( $response_message ) ) {
				return new WP_Error( $response_code, $response_message );
			} elseif ( 200 !== $response_code ) {
				return new WP_Error( $response_code, __( 'An unknown API error occurred.', 'envato-market' ) );
			} else {
				$return = json_decode( wp_remote_retrieve_body( $response ), true );
				
				return $return;
			}
			
		}

		private function process_themes( $purchased ) {
			if ( is_wp_error( $purchased ) ) {
				$purchased = array();
			}

			$current   = wp_get_theme()->get_template();
			$active    = array();
			$installed = array();
			$install   = $purchased;

			if ( ! empty( $purchased ) ) {
				foreach ( wp_get_themes() as $theme ) {

					/**
					 * WP_Theme object.
					 *
					 * @var WP_Theme $theme
					 */
					$template = $theme->get_template();
					$title    = $theme->get( 'Name' );
					$author   = $theme->get( 'Author' );

					foreach ( $install as $key => $value ) {
						if ( $this->normalize( $value['name'] ) === $this->normalize( $title ) && $this->normalize( $value['author'] ) === $this->normalize( $author ) ) {
							$installed[ $template ] = $value;
							unset( $install[ $key ] );
						}
					}
				}
			}

			if ( isset( $installed[ $current ] ) ) {
				$active[ $current ] = $installed[ $current ];
				unset( $installed[ $current ] );
			}

			self::$themes['purchased'] = array_unique( $purchased, SORT_REGULAR );
			self::$themes['active']    = array_unique( $active, SORT_REGULAR );
			self::$themes['installed'] = array_unique( $installed, SORT_REGULAR );
			self::$themes['install']   = array_unique( array_values( $install ), SORT_REGULAR );

			set_site_transient( envato_market()->get_option_name() . '_themes', self::$themes, HOUR_IN_SECONDS );
		}
	}

	new wilokeUpdate;
}

