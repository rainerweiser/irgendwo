<?php
/** 
 * Creating pi_hit_counter
 * @author pirates - Wiloke Team
 * @since 1.0
 */

function pi_pp_creating_table()
{
	if ( !get_option('pi_hit_counter') )
	{
		global $wpdb;

		$tblName = pi_pp_table_name($wpdb);

		$sql = "CREATE TABLE $tblName(
			ID bigint(20) NOT NULL AUTO_INCREMENT,
			post_id bigint(20) NOT NULL,
			views_of_day bigint(20) NOT NULL,
			comments_of_day bigint(20) NOT NULL,
			post_date DATE NOT NULL,
			PRIMARY KEY (ID) 
		)";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );

		update_option('pi_hit_counter', 1);
	}
}